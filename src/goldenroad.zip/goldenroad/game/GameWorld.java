package goldenroad.game;

import goldenroad.entity.item.Inventory;
import goldenroad.entity.item.Item;
import goldenroad.entity.monster.Monster;
import goldenroad.entity.player.Player;
import goldenroad.entity.projectile.Bullet;
import goldenroad.map.CollisionHandler;
import goldenroad.map.CollisionMap;
import goldenroad.map.MapCatalog;
import goldenroad.map.MapDefinition;
import goldenroad.map.MapId;
import goldenroad.scene.SceneManager;
import goldenroad.scene.Screen;
import goldenroad.settings.Difficulty;
import goldenroad.util.AssetLoader;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GameWorld {
    private MapId currentMapId = MapId.MAP_2;
    private CollisionMap collisionMap;
    private CollisionHandler collisionHandler;
    private BufferedImage mapImage;
    private BufferedImage hiddenImage;
    private int worldWidth;
    private int worldHeight;

    public MapId getCurrentMapId() {
        return currentMapId;
    }

    public int handleItemPickup(
            Player player,
            Inventory inventory,
            SceneManager sceneManager,
            java.util.function.Consumer<String> toast) {
        if (player == null || inventory == null || sceneManager == null)
            return 0;

        Screen currentScreen = sceneManager.getCurrentScreen();
        Rectangle playerBounds = new Rectangle(
                (int) player.getX(),
                (int) player.getY(),
                (int) player.getWidth(),
                (int) player.getHeight());

        List<Item> items = new ArrayList<>(currentScreen.getItems());
        int collectedItemCount = 0;
        for (Item item : items) {
            if (item.isCollected())
                continue;
            if (playerBounds.intersects(item.getBounds())) {
                inventory.addItem(item.getType(), 1);
                item.collect();
                currentScreen.removeItem(item);
                collectedItemCount++;
                if (toast != null) {
                    toast.accept(pickupMessage(item.getType()));
                }
            }
        }
        return collectedItemCount;
    }

    private String pickupMessage(Item.ItemType type) {
        return switch (type) {
            case HP_POTION -> "Nhat duoc HP Potion";
            case MP_POTION -> "Nhat duoc MP Potion";
            case KEY -> "Nhat duoc Key";
        };
    }

    public void updateMonsters(Player player, SceneManager sceneManager, List<Bullet> bullets) {
        updateMonsters(player, sceneManager, bullets, Difficulty.NORMAL);
    }

    public void updateMonsters(Player player, SceneManager sceneManager, List<Bullet> bullets, Difficulty difficulty) {
        if (sceneManager == null || collisionMap == null)
            return;

        List<Monster> monsters = new ArrayList<>(sceneManager.getCurrentScreen().getMonsters());
        for (Monster monster : monsters) {
            int damage = monster.update(
                    player,
                    collisionMap,
                    bullets == null ? java.util.Collections.emptyList() : bullets,
                    difficulty);
            if (damage > 0) {
                player.takeDamage(damage);
            }

            if (monster.shouldBeRemoved()) {
                sceneManager.getCurrentScreen().removeMonster(monster);
            }
        }
    }

    public int updateBullets(List<Bullet> bullets, SceneManager sceneManager) {
        if (bullets == null || bullets.isEmpty() || sceneManager == null)
            return 0;

        int defeatedMonsterCount = 0;
        Iterator<Bullet> it = bullets.iterator();
        while (it.hasNext()) {
            Bullet bullet = it.next();
            if (bullet.isDestroyed()) {
                it.remove();
                continue;
            }

            java.awt.Rectangle bounds = bullet.getBounds();
            if (isOutOfWorld(bounds) || collidesWithSolidBlock(bounds)) {
                it.remove();
                continue;
            }

            boolean hitMonster = false;
            // iterate over a copy because Screen.getMonsters() returns an unmodifiable view
            List<Monster> monstersCopy = new ArrayList<>(sceneManager.getCurrentScreen().getMonsters());
            for (Monster monster : monstersCopy) {
                if (bounds.intersects(monster.getBounds())) {
                    if (monster.takeDamage(bullet.getDamage())) {
                        defeatedMonsterCount++;
                    }
                    it.remove();
                    hitMonster = true;
                    break;
                }
            }

            if (hitMonster) {
                continue;
            }

            bullet.update();
        }
        return defeatedMonsterCount;
    }

    private boolean collidesWithSolidBlock(java.awt.Rectangle bounds) {
        if (collisionMap == null) {
            return false;
        }

        return collisionMap.isAreaSolid(bounds.x, bounds.y, bounds.width, bounds.height);
    }

    private boolean isOutOfWorld(java.awt.Rectangle bounds) {
        return bounds.x + bounds.width < 0
                || bounds.x > worldWidth
                || bounds.y + bounds.height < 0
                || bounds.y > worldHeight;
    }

    public void render(Graphics2D g, Player player, List<Bullet> bullets, SceneManager sceneManager,
            java.util.Map<Item.ItemType, BufferedImage> itemSprites) {
        if (g == null || sceneManager == null)
            return;

        // MAP
        if (mapImage != null) {
            g.drawImage(mapImage, 0, 0, null);
        }

        // ITEMS
        for (Item item : sceneManager.getCurrentScreen().getItems()) {
            if (item.isCollected())
                continue;

            java.awt.Rectangle r = item.getBounds();
            BufferedImage sprite = itemSprites == null ? null : itemSprites.get(item.getType());

            if (sprite != null) {
                g.drawImage(sprite, r.x, r.y, Item.ITEM_SIZE, Item.ITEM_SIZE, null);
            } else {
                g.setColor(item.getColor());
                if (item.getShape() == Item.Shape.OVAL) {
                    g.fillOval(r.x, r.y, r.width, r.height);
                } else {
                    g.fillRect(r.x, r.y, r.width, r.height);
                }
            }
        }

        // MONSTERS (iterate over a copy to avoid concurrent modification during update)
        for (Monster monster : new ArrayList<>(sceneManager.getCurrentScreen().getMonsters())) {
            monster.draw(g);
        }

        // BULLETS (iterate over a copy to avoid concurrent modification during update)
        if (bullets != null) {
            for (Bullet bullet : new ArrayList<>(bullets)) {
                bullet.render(g);
            }
        }

    }

    public CollisionMap getCollisionMap() {
        return collisionMap;
    }

    public CollisionHandler getCollisionHandler() {
        return collisionHandler;
    }

    public BufferedImage getMapImage() {
        return mapImage;
    }

    public BufferedImage getHiddenImage() {
        return hiddenImage;
    }

    public int getWorldWidth() {
        return worldWidth;
    }

    public int getWorldHeight() {
        return worldHeight;
    }

    public void loadCurrentMap(SceneManager sceneManager, Player player, boolean spawnInitialItems) {
        loadCurrentMap(sceneManager, player, spawnInitialItems, Difficulty.NORMAL);
    }

    public void loadCurrentMap(SceneManager sceneManager, Player player, boolean spawnInitialItems,
            Difficulty difficulty) {
        loadMap(currentMapId, sceneManager, player, spawnInitialItems, difficulty);
    }

    public void loadMap(MapId mapId, SceneManager sceneManager, Player player, boolean spawnInitialItems) {
        loadMap(mapId, sceneManager, player, spawnInitialItems, Difficulty.NORMAL);
    }

    public void loadMap(MapId mapId, SceneManager sceneManager, Player player, boolean spawnInitialItems,
            Difficulty difficulty) {
        if (mapId == null) {
            mapId = MapId.MAP_0;
        }

        loadMapInternal(mapId, sceneManager, player, spawnInitialItems, difficulty);
    }

    public void switchMap(SceneManager sceneManager, Player player, boolean spawnInitialItems) {
        switchMap(sceneManager, player, spawnInitialItems, Difficulty.NORMAL);
    }

    public void switchMap(SceneManager sceneManager, Player player, boolean spawnInitialItems, Difficulty difficulty) {
        MapId nextMapId = currentMapId == null ? MapId.MAP_0 : currentMapId.next();
        loadMapInternal(nextMapId, sceneManager, player, spawnInitialItems, difficulty);
    }

    private void loadMapInternal(MapId mapId, SceneManager sceneManager, Player player, boolean spawnInitialItems,
            Difficulty difficulty) {
        currentMapId = mapId;
        applyMap(MapCatalog.get(mapId), sceneManager, player, spawnInitialItems, difficulty);
    }

    private void applyMap(MapDefinition mapDefinition, SceneManager sceneManager, Player player,
            boolean spawnInitialItems, Difficulty difficulty) {
        mapImage = AssetLoader.loadImage(mapDefinition.getBackgroundPath());
        hiddenImage = null;

        collisionMap = new CollisionMap();
        collisionMap.load(mapDefinition.getCollisionPath());
        collisionHandler = new CollisionHandler(collisionMap);

        worldWidth = mapDefinition.getWorldWidth();
        worldHeight = mapDefinition.getWorldHeight();

        if (player != null) {
            double spawnX = clamp(mapDefinition.getSpawnX(), 0, Math.max(0, worldWidth - 1));
            double spawnY = clamp(mapDefinition.getSpawnY(), 0, Math.max(0, worldHeight - 1));
            double resolvedX = spawnX;
            double resolvedY = spawnY;

            if (collisionMap != null && collisionMap.isLoaded()) {
                double[] nearestSpawn = findNearestStandableSpawn(
                        collisionMap,
                        spawnX,
                        spawnY,
                        player.getWidth(),
                        player.getHeight(),
                        worldWidth,
                        worldHeight);

                if (nearestSpawn != null) {
                    resolvedX = nearestSpawn[0];
                    resolvedY = nearestSpawn[1];
                }
            }

            player.setX(resolvedX);
            player.setY(resolvedY);
            player.setVelocityY(0);
            player.setOnGround(true);
        }

        hiddenImage = mapDefinition.getHiddenPath() == null ? null
                : AssetLoader.loadImage(mapDefinition.getHiddenPath());

        if (spawnInitialItems && sceneManager != null && player != null) {
            sceneManager.spawnMonsters(
                    25,
                    worldWidth,
                    worldHeight,
                    collisionMap,
                    player.getX(),
                    player.getY(),
                    player.getWidth(),
                    player.getHeight());
            sceneManager.spawnMapItems(
                    sceneManager.getLastSpawnedMonsterCount(),
                    worldWidth,
                    worldHeight,
                    collisionMap,
                    player.getX(),
                    player.getY(),
                    player.getWidth(),
                    player.getHeight(),
                    difficulty);
        } else if (sceneManager != null) {
            sceneManager.getCurrentScreen().clearItems();
        }
    }

    private int clamp(int value, int min, int max) {
        if (max < min) {
            return min;
        }
        return Math.max(min, Math.min(value, max));
    }

    private double[] findNearestStandableSpawn(
            CollisionMap collisionMap,
            double desiredX,
            double desiredY,
            double entityWidth,
            double entityHeight,
            int worldWidth,
            int worldHeight) {
        if (collisionMap == null || !collisionMap.isLoaded()) {
            return null;
        }

        if (collisionMap.canStandAt(desiredX, desiredY, entityWidth, entityHeight)) {
            return new double[] { desiredX, desiredY };
        }

        int step = 8;
        int maxDistance = Math.max(worldWidth, worldHeight);
        double bestDistance = Double.MAX_VALUE;
        double bestX = desiredX;
        double bestY = desiredY;

        for (int y = 0; y <= Math.max(0, worldHeight - (int) Math.ceil(entityHeight)); y += step) {
            for (int x = 0; x <= Math.max(0, worldWidth - (int) Math.ceil(entityWidth)); x += step) {
                if (!collisionMap.canStandAt(x, y, entityWidth, entityHeight)) {
                    continue;
                }

                double distance = Math.abs(x - desiredX) + Math.abs(y - desiredY);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    bestX = x;
                    bestY = y;
                }
            }
        }

        if (bestDistance == Double.MAX_VALUE) {
            return null;
        }

        return new double[] { bestX, bestY };
    }
}
